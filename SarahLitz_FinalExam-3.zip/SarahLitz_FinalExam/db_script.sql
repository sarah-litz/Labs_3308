CREATE DATABASE bookreview_db;

\c bookreview_db; 

CREATE TABLE IF NOT EXISTS reviews ( 
    id int GENERATED ALWAYS AS IDENTITY, 
    book_title varchar(300) not null, 
    review text not null, 
    review_date date not null
);