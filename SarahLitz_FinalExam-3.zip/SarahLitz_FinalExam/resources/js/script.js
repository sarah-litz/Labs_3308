



$(document).ready(function() {
    /*          Helper Functions ( if needed)           */ 
    function submitReview() { 
        $.ajax({})
    }
    /*--------------------------------------------------*/

    document.getElementById ("search-button").addEventListener ("click", apiSearch, false); //triggers the apiSearch function
    function apiSearch(){ 
        //from HTML, retrieve args needed for api


        searchInput = document.getElementById("searchInput").value; 
        //var url = 'https://reststop.randomhouse.com/resources/works/?start=0&max=3&expandLevel=1&search=Grisham'; 
        var url = 'https://reststop.randomhouse.com/resources/works/?start=0&max=3&expandLevel=1&search=' + searchInput; 
        //  var url = ' http://reststop.randomhouse.com/resources/works/' + 'start=0&max=8&expandLevel=1&search=' + searchInput; 
        // var url = ' http://reststop.randomhouse.com/resources/works/';  //for non-localhost, w/ https

        console.log(url);
        $.ajax({url:url, dataType:"json"}).then(function(data) {
                /*$.ajax({
                    url: url,
                    type: 'GET',
                    dataType: 'json',
                    success: function (bookData) {*/

                    console.log(data); 
                    

                
                    //once books are retrieved, insert them as a card into the innerHTML
                    for ( var i = 0; i < 3; i++ ) { 
                        var myCard = 
                        ' <div style=width: 20%;">  \
                            <div class="card">   \
                                <div class="card-body"> \
                                    <h5 class="card-title"> \
                                    <p class="card-text"> '
                                        +  data.work[i].titleweb + "  " + data.work[i].authorweb 
                                    +'</p>\
                                </div> \
                                <div> \
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#reviewModal"> \
                                    Add Review \
                                </button> \
                                </div>\
                            </div> \
                        </div>';
                        document.getElementById("bookDiv").innerHTML = myCard +  document.getElementById("bookDiv").innerHTML;
                    }
        });
    }; //closing bracket for function apiSearch()
}); //closing bracket for document.ready(function() { ... 
 